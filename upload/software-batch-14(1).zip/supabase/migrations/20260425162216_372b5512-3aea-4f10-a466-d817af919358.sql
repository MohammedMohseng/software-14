
-- Academic resources
CREATE TABLE public.resources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  uploader_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  subject TEXT,
  resource_type TEXT NOT NULL DEFAULT 'link', -- 'link' | 'pdf'
  url TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.resources ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Resources viewable by everyone"
  ON public.resources FOR SELECT USING (true);

CREATE POLICY "Professors/Moderators/Admins can insert resources"
  ON public.resources FOR INSERT
  WITH CHECK (
    auth.uid() = uploader_id AND (
      public.has_role(auth.uid(), 'professor') OR
      public.has_role(auth.uid(), 'moderator') OR
      public.has_role(auth.uid(), 'admin')
    )
  );

CREATE POLICY "Uploaders can update own resources"
  ON public.resources FOR UPDATE USING (auth.uid() = uploader_id);

CREATE POLICY "Uploader or moderators can delete resources"
  ON public.resources FOR DELETE USING (
    auth.uid() = uploader_id OR
    public.has_role(auth.uid(), 'moderator') OR
    public.has_role(auth.uid(), 'admin')
  );

CREATE TRIGGER resources_set_updated_at
  BEFORE UPDATE ON public.resources
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Gallery albums
CREATE TABLE public.albums (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  cover_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.albums ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Albums viewable by everyone"
  ON public.albums FOR SELECT USING (true);

CREATE POLICY "Authenticated users can create albums"
  ON public.albums FOR INSERT WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Owners can update own albums"
  ON public.albums FOR UPDATE USING (auth.uid() = owner_id);

CREATE POLICY "Owner or moderators can delete albums"
  ON public.albums FOR DELETE USING (
    auth.uid() = owner_id OR
    public.has_role(auth.uid(), 'moderator') OR
    public.has_role(auth.uid(), 'admin')
  );

CREATE TRIGGER albums_set_updated_at
  BEFORE UPDATE ON public.albums
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Photos in albums
CREATE TABLE public.photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  album_id UUID NOT NULL REFERENCES public.albums(id) ON DELETE CASCADE,
  uploader_id UUID NOT NULL,
  url TEXT NOT NULL,
  caption TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.photos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Photos viewable by everyone"
  ON public.photos FOR SELECT USING (true);

CREATE POLICY "Authenticated users can add photos"
  ON public.photos FOR INSERT WITH CHECK (auth.uid() = uploader_id);

CREATE POLICY "Uploader or moderators can delete photos"
  ON public.photos FOR DELETE USING (
    auth.uid() = uploader_id OR
    public.has_role(auth.uid(), 'moderator') OR
    public.has_role(auth.uid(), 'admin')
  );

-- Game scores leaderboard
CREATE TABLE public.game_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  game TEXT NOT NULL, -- 'memory_match' | 'trivia'
  score INTEGER NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.game_scores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Scores viewable by everyone"
  ON public.game_scores FOR SELECT USING (true);

CREATE POLICY "Users can insert own scores"
  ON public.game_scores FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE INDEX idx_game_scores_game_score ON public.game_scores(game, score DESC);
CREATE INDEX idx_photos_album ON public.photos(album_id);
CREATE INDEX idx_resources_subject ON public.resources(subject);
