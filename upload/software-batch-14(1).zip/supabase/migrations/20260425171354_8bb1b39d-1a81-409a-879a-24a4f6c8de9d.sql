
-- ============== TRIVIA CATEGORIES & QUESTIONS ==============
CREATE TABLE public.trivia_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID
);

ALTER TABLE public.trivia_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Categories viewable by everyone"
  ON public.trivia_categories FOR SELECT USING (true);
CREATE POLICY "Admins/Moderators can insert categories"
  ON public.trivia_categories FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator'));
CREATE POLICY "Admins/Moderators can update categories"
  ON public.trivia_categories FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator'));
CREATE POLICY "Admins/Moderators can delete categories"
  ON public.trivia_categories FOR DELETE
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator'));

CREATE TABLE public.trivia_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID NOT NULL REFERENCES public.trivia_categories(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  options JSONB NOT NULL,           -- array of strings (4 options)
  correct_index INT NOT NULL CHECK (correct_index >= 0 AND correct_index <= 3),
  difficulty TEXT NOT NULL DEFAULT 'medium',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID
);

ALTER TABLE public.trivia_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Questions viewable by everyone"
  ON public.trivia_questions FOR SELECT USING (true);
CREATE POLICY "Admins/Moderators can insert questions"
  ON public.trivia_questions FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator'));
CREATE POLICY "Admins/Moderators can update questions"
  ON public.trivia_questions FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator'));
CREATE POLICY "Admins/Moderators can delete questions"
  ON public.trivia_questions FOR DELETE
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'moderator'));

CREATE TRIGGER trivia_questions_updated_at
  BEFORE UPDATE ON public.trivia_questions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============== EXTEND PROFILES ==============
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS major TEXT,
  ADD COLUMN IF NOT EXISTS academic_year TEXT,
  ADD COLUMN IF NOT EXISTS location TEXT,
  ADD COLUMN IF NOT EXISTS interests TEXT[],
  ADD COLUMN IF NOT EXISTS github_url TEXT,
  ADD COLUMN IF NOT EXISTS linkedin_url TEXT,
  ADD COLUMN IF NOT EXISTS skills TEXT[];

-- ============== STORAGE BUCKETS ==============
INSERT INTO storage.buckets (id, name, public)
VALUES ('memories', 'memories', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Memories images are publicly accessible"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'memories');

CREATE POLICY "Authenticated users can upload memory images"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'memories' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own memory images"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'memories' AND auth.uid()::text = (storage.foldername(name))[1]);

-- ============== SEED CATEGORIES + SAMPLE QUESTIONS ==============
INSERT INTO public.trivia_categories (name, description, icon) VALUES
  ('برمجة', 'أسئلة عامة في البرمجة وعلوم الحاسب', 'Code'),
  ('قواعد بيانات', 'SQL وأنظمة قواعد البيانات', 'Database'),
  ('شبكات', 'بروتوكولات وأساسيات الشبكات', 'Network'),
  ('ذكاء اصطناعي', 'مفاهيم AI و Machine Learning', 'Brain');

INSERT INTO public.trivia_questions (category_id, question, options, correct_index, difficulty)
SELECT id, 'ما هي لغة البرمجة الأساسية للويب الديناميكي؟',
       '["Python","JavaScript","C++","Ruby"]'::jsonb, 1, 'easy'
FROM public.trivia_categories WHERE name = 'برمجة';

INSERT INTO public.trivia_questions (category_id, question, options, correct_index, difficulty)
SELECT id, 'أي بنية بيانات تعمل بمبدأ LIFO؟',
       '["Queue","Array","Stack","Tree"]'::jsonb, 2, 'easy'
FROM public.trivia_categories WHERE name = 'برمجة';

INSERT INTO public.trivia_questions (category_id, question, options, correct_index, difficulty)
SELECT id, 'ماذا يعني SQL؟',
       '["Structured Query Language","Simple Query Logic","Server Quality Link","Stored Quick List"]'::jsonb, 0, 'easy'
FROM public.trivia_categories WHERE name = 'قواعد بيانات';

INSERT INTO public.trivia_questions (category_id, question, options, correct_index, difficulty)
SELECT id, 'أي مما يلي ليس قاعدة بيانات علائقية؟',
       '["MongoDB","PostgreSQL","MySQL","Oracle"]'::jsonb, 0, 'medium'
FROM public.trivia_categories WHERE name = 'قواعد بيانات';

INSERT INTO public.trivia_questions (category_id, question, options, correct_index, difficulty)
SELECT id, 'ما هو HTTP؟',
       '["لغة برمجة","بروتوكول نقل","نظام تشغيل","محرر نصوص"]'::jsonb, 1, 'easy'
FROM public.trivia_categories WHERE name = 'شبكات';

INSERT INTO public.trivia_questions (category_id, question, options, correct_index, difficulty)
SELECT id, 'أي بورت يستخدم HTTPS افتراضياً؟',
       '["80","21","443","22"]'::jsonb, 2, 'medium'
FROM public.trivia_categories WHERE name = 'شبكات';

INSERT INTO public.trivia_questions (category_id, question, options, correct_index, difficulty)
SELECT id, 'ما الذي يعنيه LLM؟',
       '["Large Language Model","Linear Logic Machine","Local Learning Module","Linked List Memory"]'::jsonb, 0, 'medium'
FROM public.trivia_categories WHERE name = 'ذكاء اصطناعي';

INSERT INTO public.trivia_questions (category_id, question, options, correct_index, difficulty)
SELECT id, 'أي مما يلي خوارزمية تعلم خاضع للإشراف؟',
       '["K-Means","Linear Regression","DBSCAN","PCA"]'::jsonb, 1, 'hard'
FROM public.trivia_categories WHERE name = 'ذكاء اصطناعي';
