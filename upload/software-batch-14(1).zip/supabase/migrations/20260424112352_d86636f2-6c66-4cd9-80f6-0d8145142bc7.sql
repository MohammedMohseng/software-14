-- Memories (social wall posts)
CREATE TABLE public.memories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (char_length(content) BETWEEN 1 AND 2000),
  image_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.memories ENABLE ROW LEVEL SECURITY;

CREATE INDEX memories_created_at_idx ON public.memories (created_at DESC);
CREATE INDEX memories_author_id_idx ON public.memories (author_id);

CREATE POLICY "Memories viewable by everyone"
ON public.memories FOR SELECT USING (true);

CREATE POLICY "Authenticated users can create memories"
ON public.memories FOR INSERT
WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Authors can update own memories"
ON public.memories FOR UPDATE
USING (auth.uid() = author_id);

CREATE POLICY "Authors can delete own memories"
ON public.memories FOR DELETE
USING (auth.uid() = author_id);

CREATE POLICY "Moderators can delete any memory"
ON public.memories FOR DELETE
USING (public.has_role(auth.uid(), 'moderator') OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER memories_updated_at
BEFORE UPDATE ON public.memories
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Likes
CREATE TABLE public.memory_likes (
  memory_id UUID NOT NULL REFERENCES public.memories(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (memory_id, user_id)
);

ALTER TABLE public.memory_likes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Likes viewable by everyone"
ON public.memory_likes FOR SELECT USING (true);

CREATE POLICY "Users can like"
ON public.memory_likes FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unlike own"
ON public.memory_likes FOR DELETE
USING (auth.uid() = user_id);