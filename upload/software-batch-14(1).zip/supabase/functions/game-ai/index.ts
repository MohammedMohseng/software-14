// Game AI — uses Lovable AI Gateway (Gemini) to play Chess and Tic-Tac-Toe
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const CHESS_PROMPT = `You are a chess engine. You will receive the current chess position in FEN notation.
Reply ONLY with a single legal move in UCI format (e.g. "e2e4", "g1f3", "e7e8q" for promotion).
No explanations, no extra text, no quotes, no markdown — just the 4 or 5 character move.`;

const TTT_PROMPT = `You are a Tic-Tac-Toe AI playing as 'O'. The user is 'X'.
You will receive the board as a 9-character string where 'X', 'O' are players and '-' is empty.
Indices: 0=top-left, 1=top-mid, 2=top-right, 3=mid-left, ..., 8=bottom-right.
Reply ONLY with a single digit 0-8 representing your move on an empty cell. Play optimally.`;

async function askAI(system: string, user: string): Promise<string> {
  const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
  if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY missing");

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
      stream: false,
    }),
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`AI gateway ${res.status}: ${txt}`);
  }
  const data = await res.json();
  return (data?.choices?.[0]?.message?.content ?? "").toString().trim();
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  try {
    const { game, payload } = await req.json();
    let move = "";

    if (game === "chess") {
      const fen = String(payload?.fen ?? "").trim();
      if (!fen) throw new Error("fen required");
      const raw = await askAI(CHESS_PROMPT, `FEN: ${fen}\nPlay the best move.`);
      const match = raw.match(/[a-h][1-8][a-h][1-8][qrbn]?/i);
      move = (match?.[0] ?? raw).toLowerCase();
    } else if (game === "tictactoe") {
      const board = String(payload?.board ?? "");
      if (board.length !== 9) throw new Error("invalid board");
      const raw = await askAI(TTT_PROMPT, `Board: ${board}\nYour move (0-8):`);
      const match = raw.match(/[0-8]/);
      move = match?.[0] ?? "";
    } else {
      throw new Error("unknown game");
    }

    return new Response(JSON.stringify({ move }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("game-ai error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
