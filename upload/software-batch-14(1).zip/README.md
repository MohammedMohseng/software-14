# دفعة 14 برمجيات — Software Batch 14 Platform

منصة موحّدة لدفعة 14 برمجيات: ذكريات، مكتبة أكاديمية، معرض صور، ألعاب، ومساعد ذكي.
- **الواجهة:** React 18 + Vite 5 + TypeScript + Tailwind (Dark Tech, RTL, خط Cairo)
- **الباك‑إند:** Supabase (Postgres + Auth + RLS + Edge Functions)
- **الذكاء الاصطناعي:** Lovable AI Gateway (Google Gemini)

---

## 🧱 الوحدات المنجزة

| الوحدة | المسار | الوصف |
|---|---|---|
| الصفحة الرئيسية | `/` | عرض تسويقي وميزات المنصة |
| التسجيل/الدخول | `/auth` | بريد + Google، مع تحقق Zod |
| الملف الشخصي | `/profile` | تعديل الاسم، النبذة، الصورة، السوشيال |
| الأعضاء | `/members` | دليل قابل للبحث |
| الذكريات | `/memories` | حائط اجتماعي + إعجابات |
| المكتبة الأكاديمية | `/academic` | روابط/PDF (يرفعها الأساتذة) |
| المعرض | `/gallery` | ألبومات + صور + Lightbox |
| الألعاب | `/games` | Memory Match + Trivia + Leaderboard |
| المساعد الذكي | `/ai` | دردشة Gemini (Streaming) |
| لوحة الأدمن | `/admin` | إدارة الأدوار (5 مستويات) |

### نظام الأدوار (RBAC)
`visitor → member → professor → moderator → admin`
- يتم تعيين دور `member` تلقائيًا عند التسجيل.
- حد أقصى 5 مشرفين (محمي بـ trigger).
- جميع الجداول محمية بسياسات RLS مع دالة `has_role` آمنة.

---

## 🚀 التشغيل المحلي

### المتطلبات
- Node.js 18+ أو Bun 1.0+
- حساب Supabase

### الخطوات
```bash
# 1) فك الضغط ثم
cd software-batch-14

# 2) تثبيت الاعتمادات
bun install         # أو: npm install

# 3) إنشاء ملف .env (انظر القسم التالي)

# 4) التشغيل
bun run dev         # أو: npm run dev
# يفتح على http://localhost:8080
```

### متغيرات البيئة `.env`
```
VITE_SUPABASE_URL="https://YOUR_PROJECT.supabase.co"
VITE_SUPABASE_PUBLISHABLE_KEY="ANON_PUBLIC_KEY"
VITE_SUPABASE_PROJECT_ID="YOUR_PROJECT_REF"
```
> القيم الحالية في `.env` تشير إلى مشروع Lovable Cloud الخاص بك. لا تحتاج لتغييرها إذا استمررت في استخدامه.

---

## 🗄️ إعداد قاعدة البيانات

كل المخططات موجودة في `supabase/migrations/`. عند الاستضافة الذاتية:
```bash
# باستخدام Supabase CLI
supabase link --project-ref YOUR_REF
supabase db push
```
أو نفّذ ملفات SQL يدويًا عبر SQL Editor في Supabase Dashboard بالترتيب الزمني.

### تفعيل تسجيل Google
1. **Supabase Dashboard → Authentication → Providers → Google**
2. أنشئ OAuth Client في [Google Cloud Console](https://console.cloud.google.com/apis/credentials)
3. أضف Redirect URI من Supabase
4. أدخل Client ID/Secret في Supabase

> ضمن Lovable Cloud: تتم إدارة هذا تلقائيًا — افتح **Cloud → Users → Auth Settings**.

---

## 🤖 إعداد المساعد الذكي

Edge Function: `supabase/functions/chat/index.ts`

- يستخدم متغير البيئة `LOVABLE_API_KEY` (مُهيّأ تلقائيًا في Lovable Cloud).
- إذا كنت على Supabase مستقل:
```bash
supabase secrets set LOVABLE_API_KEY=xxxx
supabase functions deploy chat --no-verify-jwt
```

النموذج المستخدم: `google/gemini-2.5-flash` (يمكن تغييره داخل الدالة).

---

## 🌐 النشر (Deployment)

### الخيار 1 — Lovable (أسهل)
- اضغط **Publish** أعلى يمين المحرر.
- سيُنشر الموقع تلقائيًا على `*.lovable.app`، مع إمكانية ربط نطاق مخصص.
- Edge Functions تُنشر تلقائيًا.

### الخيار 2 — Vercel / Netlify / Cloudflare Pages
1. ارفع الكود إلى GitHub.
2. اربط المستودع بمنصة الاستضافة.
3. **Build command:** `bun run build` (أو `npm run build`)
4. **Output directory:** `dist`
5. أضف متغيرات البيئة الثلاثة `VITE_SUPABASE_*`.
6. SPA Redirects: Vercel/Netlify يدعمان ذلك تلقائيًا. إن واجهت 404 على إعادة التحميل، أضف ملف `_redirects`:
   ```
   /*    /index.html   200
   ```

### الخيار 3 — استضافة ذاتية (Docker/Nginx)
```bash
bun run build
# ارفع محتويات /dist إلى الخادم وقدّمها عبر Nginx مع SPA fallback:
#   try_files $uri /index.html;
```

---

## 📁 هيكلة المشروع
```
src/
  components/     # Navbar, ProtectedRoute, ui/ (shadcn)
  contexts/       # AuthContext
  hooks/          # useUserRoles
  integrations/   # Supabase client + types (مولّدة تلقائيًا)
  pages/          # Index, Auth, Profile, Members, Memories,
                  # Academic, Gallery, Games, AIAssistant, Admin
  index.css       # Design tokens (Dark Tech HSL)
supabase/
  config.toml
  functions/chat/  # Edge function للمساعد الذكي
  migrations/      # ملفات SQL
```

---

## 🔐 ملاحظات أمنية
- جميع الجداول مفعّل عليها RLS.
- الأدوار تُخزّن في جدول `user_roles` منفصل (لمنع تصاعد الصلاحيات).
- التحقق من الدور يتم عبر دالة `has_role` بصلاحيات `SECURITY DEFINER`.
- مفتاح `LOVABLE_API_KEY` يبقى داخل Edge Function ولا يُسرَّب للعميل.

---

## 📝 الترخيص
خاص بدفعة 14 برمجيات. صُنع بحب 💙
