import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useUserRoles } from "@/hooks/useUserRoles";
import { Button } from "@/components/ui/button";
import { Code2, LogOut, Menu, User as UserIcon } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const navItems = [
  { to: "/", label: "الرئيسية" },
  { to: "/members", label: "الأعضاء" },
  { to: "/gallery", label: "المعرض" },
  { to: "/memories", label: "الذكريات" },
  { to: "/academic", label: "المكتبة الأكاديمية" },
  { to: "/games", label: "الألعاب" },
  { to: "/ai", label: "المساعد الذكي" },
];

export default function Navbar() {
  const { user, signOut } = useAuth();
  const { isAdmin } = useUserRoles();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-secondary glow-primary">
            <Code2 className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-bold gradient-text">دفعة 14</div>
            <div className="text-[10px] text-muted-foreground font-mono">SOFTWARE · BATCH 14</div>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "px-3 py-2 rounded-md text-sm font-medium transition-colors",
                pathname === item.to
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted",
              )}
            >
              {item.label}
            </Link>
          ))}
          {isAdmin && (
            <Link
              to="/admin"
              className={cn(
                "px-3 py-2 rounded-md text-sm font-medium transition-colors",
                pathname === "/admin"
                  ? "text-secondary bg-secondary/10"
                  : "text-secondary/80 hover:text-secondary hover:bg-secondary/10",
              )}
            >
              لوحة الأدمن
            </Link>
          )}
        </nav>

        <div className="hidden md:flex items-center gap-2">
          {user ? (
            <>
              <Button variant="ghost" size="sm" onClick={() => navigate("/profile")}>
                <UserIcon className="ms-1 h-4 w-4" />
                الملف الشخصي
              </Button>
              <Button variant="outline" size="sm" onClick={handleSignOut}>
                <LogOut className="ms-1 h-4 w-4" />
                خروج
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" onClick={() => navigate("/auth")}>
                دخول
              </Button>
              <Button size="sm" onClick={() => navigate("/auth?mode=signup")} className="bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90">
                انضم الآن
              </Button>
            </>
          )}
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="القائمة"
        >
          <Menu className="h-5 w-5" />
        </Button>
      </div>

      {open && (
        <div className="md:hidden border-t border-border/60 bg-background/95 backdrop-blur">
          <div className="container py-3 flex flex-col gap-1">
            {navItems.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={cn(
                  "px-3 py-2 rounded-md text-sm font-medium",
                  pathname === item.to ? "text-primary bg-primary/10" : "text-muted-foreground",
                )}
              >
                {item.label}
              </Link>
            ))}
            {isAdmin && (
              <Link to="/admin" onClick={() => setOpen(false)} className="px-3 py-2 rounded-md text-sm font-medium text-secondary">
                لوحة الأدمن
              </Link>
            )}
            <div className="border-t border-border/60 my-2" />
            {user ? (
              <>
                <Button variant="ghost" size="sm" onClick={() => { setOpen(false); navigate("/profile"); }}>
                  الملف الشخصي
                </Button>
                <Button variant="outline" size="sm" onClick={handleSignOut}>
                  تسجيل الخروج
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" size="sm" onClick={() => { setOpen(false); navigate("/auth"); }}>دخول</Button>
                <Button size="sm" onClick={() => { setOpen(false); navigate("/auth?mode=signup"); }} className="bg-gradient-to-r from-primary to-secondary text-primary-foreground">
                  انضم الآن
                </Button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
