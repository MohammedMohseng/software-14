import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type AppRole = "visitor" | "member" | "professor" | "moderator" | "admin";

export function useUserRoles() {
  const { user } = useAuth();
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setRoles([]);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .then(({ data }) => {
        if (cancelled) return;
        setRoles((data ?? []).map((r) => r.role as AppRole));
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  const has = (role: AppRole) => roles.includes(role);
  const isAdmin = has("admin");
  const isModerator = has("moderator") || isAdmin;
  const isProfessor = has("professor");
  const isMember = has("member") || isProfessor || isModerator;

  return { roles, loading, has, isAdmin, isModerator, isProfessor, isMember };
}
