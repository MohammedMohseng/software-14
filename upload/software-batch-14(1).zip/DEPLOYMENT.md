# 🚀 دليل النشر التفصيلي — Software Batch 14

دليل شامل لنشر المشروع على المنصات المجانية، مع إعداد قاعدة البيانات والمصادقة والذكاء الاصطناعي.

---

## 📋 جدول المحتويات
1. [قبل النشر — تجهيز Backend (Supabase)](#1-قبل-النشر--تجهيز-backend-supabase)
2. [النشر على Vercel](#2-النشر-على-vercel-الأسهل)
3. [النشر على Netlify](#3-النشر-على-netlify)
4. [النشر على Cloudflare Pages](#4-النشر-على-cloudflare-pages)
5. [النشر على Lovable مباشرة](#5-النشر-على-lovable-اضغط-وانتهى)
6. [إعداد تسجيل Google](#6-إعداد-تسجيل-google)
7. [إعداد المساعد الذكي (Gemini)](#7-إعداد-المساعد-الذكي-gemini)
8. [ترقية حسابك إلى أدمن](#8-ترقية-حسابك-إلى-أدمن)
9. [استكشاف الأخطاء](#9-استكشاف-الأخطاء)

---

## 1. قبل النشر — تجهيز Backend (Supabase)

> إذا كنت تستخدم **Lovable Cloud** فالـ backend جاهز فعلاً وتجاوز هذه الخطوة.

### أ) أنشئ مشروع Supabase
1. اذهب إلى [https://supabase.com](https://supabase.com) → **New Project**.
2. اختر اسماً وكلمة مرور قوية لقاعدة البيانات.
3. انتظر حتى يكتمل الإعداد (~2 دقيقة).

### ب) شغّل ملفات الـ Migrations
**الطريقة 1 — عبر SQL Editor (الأسهل):**
1. افتح **SQL Editor** في Supabase Dashboard.
2. افتح كل ملف داخل `supabase/migrations/` بالترتيب الزمني (حسب الاسم).
3. الصق المحتوى واضغط **Run**.

**الطريقة 2 — عبر Supabase CLI:**
```bash
npm i -g supabase
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

### ج) أنشئ Storage Bucket
1. **Storage → Create bucket**.
2. الاسم: `memories` — اجعله **Public**.

### د) انشر Edge Functions
```bash
supabase functions deploy chat --no-verify-jwt
supabase functions deploy game-ai --no-verify-jwt
supabase secrets set LOVABLE_API_KEY=YOUR_KEY
```
> احصل على `LOVABLE_API_KEY` من [Lovable AI Gateway](https://docs.lovable.dev/features/ai) — يمنحك وصولاً مجانياً لنماذج Gemini.

### هـ) احصل على المفاتيح
من **Project Settings → API**:
- `Project URL` → `VITE_SUPABASE_URL`
- `anon public` key → `VITE_SUPABASE_PUBLISHABLE_KEY`
- `Project Reference ID` → `VITE_SUPABASE_PROJECT_ID`

---

## 2. النشر على Vercel (الأسهل)

### الخطوات
1. ارفع الكود إلى GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/USERNAME/REPO.git
   git push -u origin main
   ```
2. اذهب إلى [vercel.com](https://vercel.com) → **Add New → Project**.
3. اختر مستودع GitHub واضغط **Import**.
4. **Framework Preset**: Vite (يُكتشف تلقائياً).
5. **Build Command**: `npm run build` أو `bun run build`
6. **Output Directory**: `dist`
7. اضغط **Environment Variables** وأضف:
   ```
   VITE_SUPABASE_URL          = https://xxx.supabase.co
   VITE_SUPABASE_PUBLISHABLE_KEY = eyJhbGciOi...
   VITE_SUPABASE_PROJECT_ID   = xxxxxxxx
   ```
8. اضغط **Deploy** ⚡.

✅ Vercel يدعم SPA routing تلقائياً (لا حاجة لإعدادات إضافية).

### ربط نطاق مخصص
**Project Settings → Domains → Add** → أدخل النطاق واتبع تعليمات DNS.

---

## 3. النشر على Netlify

1. ارفع الكود إلى GitHub (انظر الخطوة أعلاه).
2. اذهب إلى [netlify.com](https://netlify.com) → **Add new site → Import from Git**.
3. اختر المستودع.
4. **Build command**: `npm run build`
5. **Publish directory**: `dist`
6. **Site settings → Environment variables** أضف نفس المتغيرات الثلاثة.
7. أنشئ ملف `public/_redirects` (إذا لم يكن موجوداً):
   ```
   /*    /index.html   200
   ```
8. **Deploy site**.

---

## 4. النشر على Cloudflare Pages

1. ارفع الكود إلى GitHub.
2. [dash.cloudflare.com](https://dash.cloudflare.com) → **Workers & Pages → Create → Pages → Connect to Git**.
3. اختر المستودع.
4. **Framework preset**: Vite
5. **Build command**: `npm run build`
6. **Build output directory**: `dist`
7. **Environment variables** أضف الثلاثة.
8. **Save and Deploy**.

✅ Cloudflare Pages يدعم SPA fallback تلقائياً.

---

## 5. النشر على Lovable (اضغط وانتهى)

1. اضغط زر **Publish** أعلى يمين المحرر.
2. سيُنشر الموقع على `*.lovable.app` فوراً.
3. Edge Functions والـ migrations تُطبّق تلقائياً.
4. لربط نطاق مخصص: **Project Settings → Domains**.

---

## 6. إعداد تسجيل Google

### في Google Cloud Console
1. اذهب إلى [console.cloud.google.com](https://console.cloud.google.com).
2. أنشئ مشروعاً جديداً.
3. **APIs & Services → OAuth consent screen** → اختر **External** واملأ الحقول.
4. **Credentials → Create Credentials → OAuth Client ID**:
   - Application type: **Web application**
   - Authorized redirect URIs: انسخ من Supabase (الخطوة التالية).

### في Supabase Dashboard
1. **Authentication → Providers → Google** → فعّله.
2. انسخ **Callback URL** الذي يظهر.
3. الصقه في Google Cloud (Authorized redirect URIs).
4. انسخ **Client ID** و **Client Secret** من Google والصقهما في Supabase.
5. احفظ.

### في Authentication → URL Configuration
- **Site URL**: ضع رابط موقعك المنشور (مثلاً `https://yoursite.vercel.app`).
- **Redirect URLs**: أضف نفس الرابط + `https://yoursite.vercel.app/**`.

---

## 7. إعداد المساعد الذكي (Gemini)

المساعد والشطرنج الذكي يستخدمان Edge Functions:
- `supabase/functions/chat` (مساعد دردشة)
- `supabase/functions/game-ai` (الشطرنج + XO)

كلاهما يحتاج المتغير `LOVABLE_API_KEY`:
```bash
supabase secrets set LOVABLE_API_KEY=your_key_here
```
في Lovable Cloud هذا المفتاح **مُهيّأ تلقائياً**.

---

## 8. ترقية حسابك إلى أدمن

بعد التسجيل لأول مرة، نفّذ في **SQL Editor**:
```sql
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role
FROM auth.users
WHERE email = 'your-email@example.com';
```
الآن يظهر لك زر **لوحة الإدارة** ويمكنك:
- إدارة الأدوار (5 مستويات).
- إنشاء فئات أسئلة وإضافة/تعديل الأسئلة.
- **استيراد أسئلة عبر JSON** (استخدم زر "قالب JSON" لرؤية التنسيق).

### تنسيق ملف JSON للأسئلة
```json
[
  {
    "category": "اسم الفئة الموجودة",
    "question": "ما هو ناتج 2 + 2؟",
    "options": ["3", "4", "5", "22"],
    "correct_index": 1,
    "difficulty": "easy"
  },
  {
    "category": "برمجة",
    "question": "أي لغة تعمل في المتصفح؟",
    "options": ["Python", "JavaScript", "Ruby", "Go"],
    "answer": "JavaScript",
    "difficulty": "medium"
  }
]
```
- `category`: اسم فئة موجودة مسبقاً (أنشئها أولاً من تبويب الفئات).
- `correct_index` (0-based) **أو** `answer` (نص يطابق أحد الخيارات).
- `difficulty`: `easy` / `medium` / `hard` (افتراضي `medium`).

---

## 9. استكشاف الأخطاء

| المشكلة | الحل |
|---|---|
| **404 عند تحديث الصفحة** | أضف ملف `_redirects` (Netlify) أو تأكد أن المنصة تدعم SPA. |
| **خطأ Auth: redirect_uri_mismatch** | تأكد أن Site URL و Redirect URLs في Supabase تطابق دومين الإنتاج. |
| **المساعد الذكي لا يردّ** | تحقق من `LOVABLE_API_KEY` في Edge Function secrets. |
| **الشطرنج لا يحرّك** | افتح Console — إذا ظهر 401/500 فالسبب نفس مشكلة المفتاح أعلاه. |
| **لا أرى لوحة الإدارة** | شغّل SQL في الخطوة 8 لإسناد دور `admin` لحسابك. |
| **رفع الصور لا يعمل** | تأكد من إنشاء bucket `memories` كـ Public. |
| **CORS errors في Edge Functions** | تأكد من نشرها بـ `--no-verify-jwt`. |

---

## ✅ بعد النشر — قائمة التحقق

- [ ] الصفحة الرئيسية تفتح.
- [ ] التسجيل بالبريد يعمل + رسالة تأكيد البريد تصل.
- [ ] تسجيل Google يعمل.
- [ ] لوحة الإدارة ظاهرة بعد ترقية حسابك.
- [ ] استيراد JSON للأسئلة ينجح.
- [ ] لعبة الشطرنج تردّ على حركاتك.
- [ ] المساعد الذكي يستجيب.
- [ ] رفع صورة في "الذكريات" يعمل.

🎉 مبروك! منصة دفعة 14 جاهزة.
